import{a as t}from"../chunks/eHbxn8k9.js";export{t as start};
